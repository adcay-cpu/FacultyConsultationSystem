# CCS Faculty Consultation Booking System

A local school-project system built with **Node.js, Express, EJS, SQLite, jQuery, express-session, bcryptjs, Nodemailer, and dotenv**. The existing glassmorphism interface, landing page, consultation workflows, chat attachments, and sign-in screen are preserved.

## Features

- Server-verified sign-in with bcryptjs password hashes and express-session.
- Bulk account import from CSV, TSV, TXT, JSON, or Excel with a server-side valid/invalid preview before confirmation.
- Duplicate account ID and duplicate email detection against the SQLite database.
- Role, email, program, and required-field validation. Faculty accounts require at least one subject.
- One-time password setup links sent by SMTP are still supported for accounts created by earlier versions.
- New accounts receive a random temporary password by email and must change it at first sign-in.
- Server-side, only bcrypt hashes are stored; temporary passwords are never written to logs. The seeded accounts in `js/app.js` list their one-time temporary passwords for local testing only — see the warning below and remove those `pw` fields before sharing or deploying.
- Admin email delivery status with retry. Retrying issues a new temporary password and invalidates the previous one.
- Administrators can add or change an existing account's email address from **Accounts**. If the account still needs its first password change, saving the email also issues and emails a new temporary password.
- Stored setup-token hashes remain expiring and single use for legacy links.
- Admin password resets issue a random temporary password, email it when an address is on file, and require a change on the user's first sign-in.
- Password change and admin password reset use server routes; passwords are never written to logs.
- User-chosen passwords must be 8-72 characters and include an uppercase letter, a lowercase letter, a number, and a symbol. The change screen shows a live checklist and strength meter, and the server enforces the same rules.
- Existing bookings, messages, uploads, accounts, and database records are preserved.

> **Local demo passwords:** the seeded accounts in `js/app.js` carry their current one-time temporary passwords in `pw` fields so the project can be demonstrated without email. Anyone who can read the file can sign in with those accounts until each password is changed. The values stop working after the first sign-in change or an administrator reset. Remove the `pw` fields and rotate those passwords before sharing, publishing, or deploying the project.

## Requirements

- Node.js 18 or later
- npm
- An SMTP account for automatic account emails (Gmail, Microsoft 365, cPanel, school mail, etc.)

The booking system itself runs without SMTP, but new accounts cannot receive their temporary password until SMTP is configured.

## Install and run

1. Open a terminal in the project folder.
2. Install dependencies:

   ```powershell
   npm install
   ```

3. Open `.env` and set the SMTP values for your own mail account. The local `.env` is already configured for the deployment's Gmail account and contains a generated `SESSION_SECRET`; replace the credentials before sharing or moving the project. `.env.example` documents every option.
4. Start the server:

   ```powershell
   npm start
   ```

5. Open `http://localhost:3000`.
6. Sign in as an administrator, open **Accounts**, and use **Bulk import accounts** or **Add one account**.

For development with automatic restart:

```powershell
npm run dev
```

## Environment variables

`.env` is loaded by the server through dotenv and is ignored by Git. Never commit real credentials, and never put SMTP passwords or setup tokens in source code.

| Variable | Purpose | Example |
| --- | --- | --- |
| `PORT` | HTTP port | `3000` |
| `NODE_ENV` | Express environment mode (`development` or `production`) | `development` |
| `APP_BASE_URL` | Public URL used in setup-link emails. It must be reachable by the recipient. | `https://consultations.cspc.edu.ph` |
| `SESSION_SECRET` | Required long random string (32+ characters) used to sign session cookies. The server refuses to start if it is missing or still a placeholder. | generated random value |
| `DB_PATH` | Optional SQLite file override | `C:\backups\ccs-consultation.sqlite` |
| `SMTP_HOST` | SMTP server hostname | `smtp.gmail.com` |
| `SMTP_PORT` | SMTP port | `587` |
| `SMTP_SECURE` | Use implicit TLS (usually `true` only for port 465) | `false` |
| `SMTP_REQUIRE_TLS` | Require STARTTLS on non-secure ports | `true` |
| `SMTP_USER` | SMTP username | `your-address@my.cspc.edu.ph` |
| `SMTP_PASS` | SMTP password or app password | provider app password |
| `MAIL_FROM` | From address/name shown to recipients | `CCS Consultation <no-reply@my.cspc.edu.ph>` |
| `SMTP_TLS_REJECT_UNAUTHORIZED` | Verify the SMTP TLS certificate | `true` |
| `SETUP_TOKEN_TTL_HOURS` | Setup-link lifetime in hours, 1–720 | `48` |
| `EMAIL_QUEUE_CONCURRENCY` | Maximum concurrent email sends, 1–10 | `3` |
| `ALLOWED_EMAIL_DOMAINS` | Optional comma-separated approved domains. Subdomains are accepted. Leave blank to allow any valid email. | `my.cspc.edu.ph` |

### Gmail example

1. Enable 2-step verification on the Google account.
2. Create a Google **App Password** for Mail.
3. Use the implicit-TLS values (port 465) or the STARTTLS values (port 587):

   ```dotenv
   # Port 465 (implicit TLS)
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=465
   SMTP_SECURE=true

   # Or port 587 (STARTTLS)
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_REQUIRE_TLS=true

   SMTP_USER=your-address@gmail.com
   SMTP_PASS=the-16-character-app-password
   MAIL_FROM="CCS Consultation <your-address@gmail.com>"
   ```

   Use `MAIL_FROM` for the sender; the server does not read a separate `SMTP_FROM` variable. If `MAIL_FROM` is blank, the `SMTP_USER` address is used.

4. Restart the server after changing `.env`.

For a school mail server, use the SMTP host, port, and credentials supplied by the IT office. If the provider uses a self-signed certificate, fix the certificate instead of disabling TLS verification.

## Bulk account import

The example file is [`accounts-import-example.csv`](./accounts-import-example.csv). The import accepts `.csv`, `.tsv`, `.txt`, `.json`, `.xlsx`, and `.xls` files up to 2 MB.

Required columns:

- `id` — unique User ID / student number / faculty ID
- `name` — full name
- `email` — unique email address; the temporary password is sent here. Use the school format: first two letters of the first name + last name, e.g. `ma.santos@my.cspc.edu.ph`

Optional columns:

- `role` — `student`, `faculty`, `admin`, or `administrator`
- `program` — program for students, or position/office for faculty and administrators
- `subject` — subject(s) taught by faculty, separated by `;` or `|`

Example:

```csv
id,name,email,role,program,subject
2024-0201,Ana Reyes,an.reyes@my.cspc.edu.ph,student,BS Information Technology,
2024-0202,Mark Dela Cruz,ma.delacruz@my.cspc.edu.ph,student,BS Computer Science,
F-1011,Prof. Lea Cruz,le.cruz@my.cspc.edu.ph,faculty,IT Instructor,Operating Systems; Computer Architecture
A-0002,CCS Admin Office,cc.admin@my.cspc.edu.ph,admin,CCS Admin Office,
```

Import rules:

- If a row has no `role`, the role selected in the import panel is used.
- If a row has a `role`, it must match the selected import role. A student row cannot be imported while **Faculty** is selected.
- IDs are unique, case-insensitively, across the SQLite `accounts` table.
- Emails are unique, case-insensitively, across the SQLite `accounts` table.
- Student programs must be one of:
  - BS Computer Science
  - BS Information Technology
  - BS Information System
  - Bachelor of Library and Information Science
- Faculty and administrator rows may use a free-text position or office.
- Faculty rows must include at least one subject.
- At most 500 accounts per import, because each temporary password is bcrypt-hashed before insertion.
- Passwords are **not** accepted in the import file. Each new account gets a random temporary password by email.
- The preview is produced by the server. The confirmation step revalidates and imports all valid rows inside a SQLite transaction.
- Duplicate IDs/emails, role mismatches, missing fields, and invalid email addresses are shown per row and are not imported.

## Account creation email flow

1. An administrator imports or creates an account.
2. The server generates a 12-character temporary password, stores only its bcrypt hash, and saves the account with `password_set = 1` and `must_change_password = 1`.
3. The User ID and temporary password are returned once to the administrator and shown in the **Temporary passwords** panel on the Accounts page.
4. Nodemailer emails the same details to the address on file:

   ```text
   User ID: 2024-0201
   Temporary password: ...
   Sign in: https://your-host/
   ```

   The email also states that the password must be changed after signing in.

5. The recipient signs in with the temporary password. The interface blocks the dashboard and requires a new password of 8-72 characters containing uppercase, lowercase, number, and symbol.
6. Changing the password stores a new bcrypt hash, clears `must_change_password`, and makes the temporary password stop working.
7. Until the password is changed, protected booking, chat-upload, account-management, import, delivery, and reset APIs return `403` with code `PASSWORD_CHANGE_REQUIRED`. The password-change endpoint remains available.

The temporary password does not expire on a timer; it stops working as soon as the user replaces it, or when an administrator resets it.

> **Security note:** temporary passwords are sent in plain text email by design for this workflow. Anyone with access to the mailbox can sign in once, so configure HTTPS, keep mailboxes secure, and change the password immediately. The administrator panel and API response show each temporary password exactly once, and it is never written to logs.

### Adding or changing an account email

Existing accounts may have been created before an email was required. Use **Add email** or **Edit email** in the Accounts table to attach a valid address:

1. The address is validated against `ALLOWED_EMAIL_DOMAINS` and checked case-insensitively for duplicates.
2. If the account is still waiting for its first password change (`must_change_password = 1`), saving the email also issues a new temporary password, emails it, and shows it once in the temporary-password popup.
3. If the account has already changed its password, saving only stores the email so future resets can reach the account holder. Use **Reset password** when a new temporary password is needed.
4. **Reset password** now emails the new temporary password when a valid address is on file. If no email is on file, the popup still shows the password for secure manual delivery.

### Legacy setup links

Accounts created by earlier versions of this project may still have a pending setup link. Those links keep working:

1. The old account has `password_set = 0` and an unusable placeholder hash.
2. The email contains a link such as `https://your-host/setup?token=...`.
3. Only the SHA-256 hash of the token is stored in `account_setup_tokens`; links expire and can be used once.
4. The recipient creates a password, which is stored as a bcrypt hash.

New accounts no longer receive setup links. Retrying an old pending account's email issues a temporary password instead and revokes any unused setup link.

### Delivery status and retries

The **Account email delivery** panel on the Accounts page shows each account email as **Pending**, **Sent**, or **Failed**, with the attempt count and the provider error when available.

- **Retry** is available while the account still has a temporary password to change, or while it is a legacy pending account.
- A retry generates a **new** temporary password, updates its bcrypt hash, and emails it. The previous temporary password stops working immediately.
- A retry updates the existing delivery row; it does not create another account.
- Once a person has changed their password, retry is refused with `409`. Use **Reset password** in the account list to issue a new temporary password.
- If email is not configured, the delivery is marked failed with a configuration message. Fill in SMTP settings, restart the server, and retry.
- Email content is never written to logs, and Nodemailer debug logging is disabled.

## Data storage and migrations

SQLite creates `data/ccs-consultation.sqlite` automatically on first run. Existing data is kept when the server upgrades the schema. The migration adds:

- `accounts.email`, `accounts.password_set`, and `accounts.must_change_password`
- `account_setup_tokens` (kept for legacy setup links)
- `email_deliveries.token_id`, `email_deliveries.kind`, and `email_deliveries.delivery_version`
- a case-insensitive unique email index and supporting indexes

Back up the SQLite file before upgrading a production copy. To test against a copy without touching the live database, set `DB_PATH` before starting:

```powershell
$env:DB_PATH = "C:\temp\ccs-test.sqlite"
$env:PORT = "3001"
npm start
```

The client still hydrates its compatibility state from SQLite, but account and password authority is server-side. Legacy client password fields are stripped from `/api/app-state` responses and persistence; server-side, only bcrypt hashes in the `accounts` table are stored. The fixed seed list in `js/app.js` is the only place that keeps plaintext demo passwords, and those are not accepted by the login API unless they match the current hash. The old `/api/app-state` route only bootstraps account rows when the `accounts` table is empty; after that, account creation and password changes must use the validated API routes. This prevents a browser request from resetting server-side audit logs or overwriting pending account hashes.

## API endpoints

- `GET /api/health` — server status.
- `GET /api/app-state`, `PUT /api/app-state` — compatibility state hydration and persistence.
- `POST /api/login`, `GET /api/session`, `POST /api/logout` — session authentication.
- `GET /api/bookings`, `POST /api/bookings`, `PATCH /api/bookings/:id/status` — booking data.
- `GET /api/accounts` — account list (administrator).
- `POST /api/accounts` — create one account; returns and emails a temporary password (administrator).
- `POST /api/admin/accounts/import/preview` — server-side import preview (administrator).
- `POST /api/admin/accounts/import` — transactional import; returns the temporary passwords for created accounts (administrator).
- `GET /api/admin/email-deliveries` — account email status (administrator).
- `POST /api/admin/email-deliveries/:id/retry` — issue a new temporary password and retry the email (administrator).
- `POST /api/admin/accounts/:username/reset-password` — admin reset; returns a random temporary password, emails it when possible, and requires a first-login change (administrator).
- `POST /api/admin/accounts/:username/email` — add or change an account email after validation (administrator).
- `POST /api/account/password` — change the signed-in user's password; also clears a pending first-login requirement.
- `POST /api/setup-password` — complete a legacy setup using a token.
- `GET /setup?token=...` — legacy password setup page.

## Testing notes

The temporary-password flow was exercised end-to-end against a copied SQLite database and a local SMTP capture server: server-backed import preview (duplicate ID/email, role mismatch, invalid email, invalid program), transactional import, bcrypt storage, the forced-change flag, emailed User ID and temporary password, duplicate re-import blocking, temporary-password sign-in, protected-API `403` responses before the change, same-password rejection, successful change, old-password rejection, retry refusal after completion, an administrator reset that invalidates the previous password and queued email jobs, a forced SMTP failure, retry with a new password that invalidates the old one, no duplicate accounts, legacy setup-link completion/expiry/single-use, log hygiene, and persistence across a restart.

The account-email update flow was tested against a copied database: adding a missing email, duplicate-email rejection, approved-domain rejection, automatic temporary-password issue for an account still pending its first change, no reset for an account that had already changed its password, reset email queuing with an on-file address, manual temporary-password delivery when no address exists, persisted email after the update, and the email popup's focus, scroll lock, and Escape close.

The admin Accounts UI (Temporary passwords panel, import preview, delivery status panel), the forced first-login change screen, and the legacy setup page were browser-tested against a copied database. Fresh-database bootstrap and migration of the existing 16-account database were verified.

Real delivery through the Gmail SMTP account in `.env` was verified on 27 October 2026: a credentials message was accepted by `smtp.gmail.com`, the delivery row moved from `pending` to `sent` with `attempts = 1` and no error, the temporary password did not appear in the server log, and the account was stored with a bcrypt hash and `must_change_password = 1`. Provider acceptance was confirmed; final inbox/spam placement depends on the recipient mailbox and was not machine-verified.

`npm audit` currently reports 7 advisories in transitive build-time packages under `sqlite3`/`node-gyp`. npm's suggested fix upgrades `sqlite3` to 6.x, which is a breaking change; plan and test that upgrade separately.

## Production notes

- No demo credentials are stored in the client bundle. The sign-in page reads accounts from the SQLite `accounts` table only, so remove or replace test accounts in the database before go-live.
- Temporary passwords are emailed by design. Make sure only the intended recipient controls the mailbox, and require the password to be replaced at first sign-in.
- Replace the default in-memory express-session store with a persistent store before multi-user production use.
- Use HTTPS and set `APP_BASE_URL` to the public HTTPS URL so sign-in links in account emails are not sent over plain HTTP.
- Keep the SQLite file and `.env` out of public/shared source control.
- Use a long random `SESSION_SECRET`.
- Configure SPF/DKIM with the mail provider so account emails are not treated as spam.
